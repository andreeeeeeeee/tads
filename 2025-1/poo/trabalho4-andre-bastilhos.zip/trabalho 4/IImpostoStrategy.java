public interface IImpostoStrategy {
  public float calcularImposto(IProduto produto, float valorBase);
}
