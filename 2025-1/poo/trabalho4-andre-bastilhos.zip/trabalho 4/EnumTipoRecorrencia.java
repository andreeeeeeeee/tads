
public enum EnumTipoRecorrencia {
  MENSAL,
  TRIMESTRAL,
  ANUAL;
}
