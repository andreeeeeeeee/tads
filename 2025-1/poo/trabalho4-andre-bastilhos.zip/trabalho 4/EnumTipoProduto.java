
public enum EnumTipoProduto {
  DIGITAL,
  FISICO,
  ASSINATURA
}
